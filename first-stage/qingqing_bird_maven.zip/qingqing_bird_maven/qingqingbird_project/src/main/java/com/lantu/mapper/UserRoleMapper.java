package com.lantu.mapper;

import com.lantu.entity.UserRole;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author laocai
 * @since 2023-09-25
 */
public interface UserRoleMapper extends BaseMapper<UserRole> {

}
