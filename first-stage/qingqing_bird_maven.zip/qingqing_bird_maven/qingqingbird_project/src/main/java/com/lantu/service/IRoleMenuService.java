package com.lantu.service;

import com.lantu.entity.RoleMenu;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author laocai
 * @since 2023-09-25
 */
public interface IRoleMenuService extends IService<RoleMenu> {

}
