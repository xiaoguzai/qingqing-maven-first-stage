import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class XAdminApplication {
    public static void main(String[] args) {
        SpringApplication.run(XAdminApplication.class, args);
    }
}
